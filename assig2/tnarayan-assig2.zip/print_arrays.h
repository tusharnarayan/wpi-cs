/** File print_arrays.h
 * @author Mike Ciaraldi
 *
 * Header file for functions that get array input and print arrays.
 */

#ifndef PRINT_ARRAYS_H
#define PRINT_ARRAYS_H

// function prototypes:

void print_int_array(int a[], int size);
void print_double_array(double a[], int size);
int get_array_input(int grades[], int MAX_GRADES, int MAX_VALID_VALUE);

#endif
